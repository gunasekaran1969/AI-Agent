import http from "node:http";
import { URL } from "node:url";
import OpenAI from "openai";

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;

if (!API_KEY) {
  console.error("Missing OPENAI_API_KEY. Set it as an environment variable before starting the server.");
  process.exit(1);
}

const client = new OpenAI({ apiKey: API_KEY });

const SYSTEM_INSTRUCTIONS = `
You are AI Agent, a helpful general-purpose assistant.
Answer the user's actual question directly and accurately.
You can help with education, coding, business analysis, Excel/SQL concepts,
writing, planning, explanations, brainstorming, and everyday questions.
When the user asks for current or time-sensitive information, use web search.
When using web search, clearly distinguish current sourced facts from general knowledge.
Do not invent facts, links, prices, statistics, or sources.
For complex tasks, give practical step-by-step instructions.
Keep answers readable with headings and bullet points when useful.
If the user asks for code, provide complete working code when practical.
`;

const rate = new Map();

function allowed(ip) {
  const now = Date.now();
  const windowMs = 60_000;
  const max = 20;
  const entry = rate.get(ip) || { start: now, count: 0 };
  if (now - entry.start >= windowMs) {
    rate.set(ip, { start: now, count: 1 });
    return true;
  }
  entry.count++;
  rate.set(ip, entry);
  return entry.count <= max;
}

function send(res, status, data, type = "application/json; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": type,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  res.end(type.startsWith("application/json") ? JSON.stringify(data) : data);
}

async function readBody(req) {
  let body = "";
  for await (const chunk of req) {
    body += chunk;
    if (body.length > 20000) throw new Error("Request too large");
  }
  return JSON.parse(body || "{}");
}

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#101827">
<title>AI Agent</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#eef3f9;color:#162033}
.app{min-height:100vh;display:flex;flex-direction:column;max-width:1000px;margin:auto;background:#fff;box-shadow:0 0 40px #00000012}
header{background:linear-gradient(135deg,#101827,#2563eb);color:#fff;padding:18px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px}
.brand{display:flex;align-items:center;gap:12px}.logo{width:44px;height:44px;border-radius:14px;background:#ffffff20;display:grid;place-items:center;font-size:24px}.title{font-size:20px;font-weight:800}.sub{font-size:12px;opacity:.8;margin-top:2px}
button{border:0;border-radius:12px;padding:11px 14px;font-weight:700;cursor:pointer}
#newChat{background:#fff;color:#1d4ed8}
main{flex:1;display:flex;flex-direction:column;min-height:0}
#messages{flex:1;overflow:auto;padding:22px 16px 110px;scroll-behavior:smooth}
.msg{display:flex;margin:0 auto 16px;max-width:850px}.msg.user{justify-content:flex-end}
.bubble{max-width:82%;padding:13px 15px;border-radius:18px;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere}
.user .bubble{background:#2563eb;color:#fff;border-bottom-right-radius:5px}
.assistant .bubble{background:#f1f5f9;color:#172033;border-bottom-left-radius:5px}
.welcome{max-width:850px;margin:18px auto 30px;padding:20px;border-radius:20px;background:linear-gradient(135deg,#eff6ff,#f8fafc);border:1px solid #dbeafe}
.welcome h2{margin:0 0 8px}.welcome p{margin:0 0 14px;color:#475569}
.chips{display:flex;flex-wrap:wrap;gap:8px}.chip{background:#fff;border:1px solid #dbe3ef;color:#334155}
.composer{position:sticky;bottom:0;background:#ffffffee;backdrop-filter:blur(10px);border-top:1px solid #e5e7eb;padding:12px 14px calc(12px + env(safe-area-inset-bottom))}
.form{max-width:850px;margin:auto;display:flex;gap:8px;align-items:flex-end}
textarea{flex:1;resize:none;min-height:48px;max-height:150px;border:1px solid #cbd5e1;border-radius:15px;padding:13px 14px;font:inherit;outline:none}
textarea:focus{border-color:#2563eb;box-shadow:0 0 0 3px #2563eb18}
#send{background:#2563eb;color:white;min-height:48px;min-width:72px}
#send:disabled{opacity:.55;cursor:not-allowed}
.status{font-size:11px;color:#64748b;text-align:center;margin-top:6px}
@media(max-width:600px){header{padding:14px}.bubble{max-width:90%}.welcome{margin:8px 0 22px}.title{font-size:18px}}
</style>
</head>
<body>
<div class="app">
<header>
  <div class="brand"><div class="logo">🤖</div><div><div class="title">AI Agent</div><div class="sub">General-purpose intelligent assistant</div></div></div>
  <button id="newChat">New Chat</button>
</header>
<main>
<section id="messages">
  <div class="welcome" id="welcome">
    <h2>How can I help you?</h2>
    <p>Ask questions, create content, learn, code, analyze business ideas, or ask for current information.</p>
    <div class="chips">
      <button class="chip">Explain SQL for a beginner</button>
      <button class="chip">Create a business plan</button>
      <button class="chip">Help me build a website</button>
      <button class="chip">Give me a study plan</button>
    </div>
  </div>
</section>
</main>
<div class="composer">
  <form class="form" id="form">
    <textarea id="input" placeholder="Ask anything..." autocomplete="off"></textarea>
    <button id="send" type="submit">Send</button>
  </form>
  <div class="status" id="status">AI responses may contain mistakes. Verify important information.</div>
</div>
</div>
<script>
const messages = document.getElementById("messages");
const input = document.getElementById("input");
const send = document.getElementById("send");
const status = document.getElementById("status");
const welcome = document.getElementById("welcome");
let previousResponseId = null;

function addMessage(role, text) {
  welcome?.remove();
  const row = document.createElement("div");
  row.className = "msg " + role;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.appendChild(bubble);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
  return bubble;
}

async function ask(text) {
  if (!text.trim() || send.disabled) return;
  addMessage("user", text.trim());
  input.value = "";
  input.style.height = "48px";
  send.disabled = true;
  status.textContent = "AI Agent is thinking...";
  const bubble = addMessage("assistant", "Thinking...");

  try {
    const r = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ message: text.trim(), previousResponseId })
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Request failed");
    bubble.textContent = data.answer || "No answer returned.";
    previousResponseId = data.responseId || null;
    status.textContent = "Ready";
  } catch (e) {
    bubble.textContent = "Error: " + e.message;
    status.textContent = "Please try again.";
  } finally {
    send.disabled = false;
    input.focus();
  }
}

document.getElementById("form").addEventListener("submit", e => {
  e.preventDefault();
  ask(input.value);
});

input.addEventListener("input", () => {
  input.style.height = "48px";
  input.style.height = Math.min(input.scrollHeight, 150) + "px";
});
input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    document.getElementById("form").requestSubmit();
  }
});

document.querySelectorAll(".chip").forEach(b => b.addEventListener("click", () => ask(b.textContent)));

document.getElementById("newChat").addEventListener("click", () => {
  previousResponseId = null;
  messages.innerHTML = "";
  const w = document.createElement("div");
  w.className = "welcome";
  w.innerHTML = "<h2>New conversation</h2><p>What would you like to do?</p>";
  messages.appendChild(w);
  input.focus();
});
</script>
</body>
</html>`;

const server = http.createServer(async (req, res) => {
  const ip = req.socket.remoteAddress || "unknown";

  if (req.method === "GET" && new URL(req.url, `http://${req.headers.host}`).pathname === "/") {
    return send(res, 200, html, "text/html; charset=utf-8");
  }

  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === "GET" && url.pathname === "/health") {
    return send(res, 200, { ok: true, service: "AI Agent" });
  }

  if (req.method === "POST" && url.pathname === "/api/chat") {
    if (!allowed(ip)) return send(res, 429, { error: "Too many requests. Please wait a minute." });

    try {
      const body = await readBody(req);
      const message = typeof body.message === "string" ? body.message.trim() : "";
      const previousResponseId =
        typeof body.previousResponseId === "string" && body.previousResponseId.length < 200
          ? body.previousResponseId
          : undefined;

      if (!message) return send(res, 400, { error: "Please enter a question." });
      if (message.length > 8000) return send(res, 400, { error: "Message is too long. Keep it under 8,000 characters." });

      const response = await client.responses.create({
        model: "gpt-5.6-luna",
        instructions: SYSTEM_INSTRUCTIONS,
        input: message,
        previous_response_id: previousResponseId,
        tools: [{ type: "web_search" }]
      });

      return send(res, 200, {
        answer: response.output_text || "I could not produce a text answer.",
        responseId: response.id
      });
    } catch (error) {
      console.error(error);
      const status = error?.status >= 400 && error?.status < 600 ? error.status : 500;
      return send(res, status, {
        error: status === 401
          ? "OpenAI API authentication failed. Check your OPENAI_API_KEY."
          : "The AI request failed. Check the server log and try again."
      });
    }
  }

  send(res, 404, { error: "Not found" });
});

server.listen(PORT, () => {
  console.log(`AI Agent running at http://localhost:${PORT}`);
});
