# Complete AI Agent

A mobile-friendly general-purpose AI Agent using the OpenAI Responses API.

## Files

- `server.js` — complete web interface + secure backend API
- `package.json` — Node.js dependency and start command
- `.env.example` — environment-variable template
- `.gitignore` — prevents the API key and node_modules from being uploaded

## Run locally

1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run:

   npm install

4. Create a file named `.env` and put your API key in it:

   OPENAI_API_KEY=your_real_key_here

5. Start:

   node --env-file=.env server.js

6. Open:

   http://localhost:3000

Never put your real API key inside `server.js`, `index.html`, GitHub Pages, or other browser-side code.

## Deploying

This is a Node.js server application, so it needs a host that can run Node.js (for example Vercel or another Node-capable host). GitHub Pages alone cannot run the backend API.

Set the environment variable `OPENAI_API_KEY` in the hosting provider's project settings, then deploy.

## Features

- General Q&A
- Multi-turn conversation using Responses API response IDs
- Web search tool for current information
- Mobile responsive interface
- New Chat button
- Basic per-IP rate limiting
- API key stays on the server
- No database required for the first version

## Important

OpenAI API usage is billed according to the API account/model usage. Creating the website code itself does not provide free API credits.
